JournalName = []

while True:
    print('Enter name of you paper' +str(len(JournalName)+1)+' (Or enter nothing to stop.)')
    name = input()
    if name == '':
        break
    else:
        JournalName = JournalName + [name]

print('You have published:')
for name in JournalName:
    print(' '+name.upper(),end=' ')
    
