import requests
import json
#UA Mask user agent
headers = {
     'User-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.4 Safari/605.1.15'
}

url = 'https://movie.douban.com/j/chart/top_list'

param = {
     'type':'4',
     'interval_id':'100:90',
     'action':' ',
     'start':'0',#from data 0 to fetch the movie
     'limit':'20',#how much will be fetched once
}

response = requests.get(url=url,params=param,headers=headers)

list_data = response.json()

fp = open('./douban.json','w',encoding='utf-8')

json.dump(list_data,fp=fp,ensure_ascii=False)

print('this project is over')