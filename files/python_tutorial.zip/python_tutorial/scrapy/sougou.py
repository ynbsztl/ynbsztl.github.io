import requests


#UA Mask user agent
headers = {
     'User-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.4 Safari/605.1.15'
}
#brower collecting bin
url = 'http://www.sogou.com/web'

#prosess the parameter url with:embed in dictionary
kw = input('enter a word:')

# 带入我们发送的请求(keywords.)

param = {
     'query':kw
}

response = requests.get(url=url,params=param,headers=headers) 

page_text = response.text
fileName = kw+'.html'
with open(fileName,'w',encoding='utf-8') as fp:
     fp.write(page_text)
print(fileName,'Save Success')

