def topfive():
    journals = ['AER', 'QJE', 'ECTA', 'JPE', 'RES']
    for journal in journals:
        print('I will publish ' + journal)
    
def topsix():
    print('You will publish '+ 'Econ. J')
    print('He will publish '+ 'J. European Econ. Assoc.')
    print('She will publish '+ 'Rev. Econ. and Statis.')      

def targetJournal(journal):
    print('I want to publish: '+journal)


