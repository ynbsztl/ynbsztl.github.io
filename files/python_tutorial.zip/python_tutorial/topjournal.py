def topfive():
    journals = ['AER', 'QJE', 'ECTA', 'JPE', 'RES']
    for journal in journals:
        print('I will publish ' + journal)
    
def topsix():
    print('You will publish '+ 'EJ')
    print('You will publish '+ 'JEEA')
    print('You will publish '+ 'RE stat.')      
    
def targetJournal(journal):
    print('I want to publish: '+journal)
    